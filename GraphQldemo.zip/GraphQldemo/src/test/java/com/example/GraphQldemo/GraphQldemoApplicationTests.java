package com.example.GraphQldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphQldemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
