package com.example.springpractice1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component // used to detect and  ingect the class objects
@Scope(value = "prototype") // to avoid the single ton approch and the class objects are called when class is called
// diffrent scopes are Singleton (default) , prototype , request , session , globalSession
public class Alian {
    private int aid;
    private String name;
    private String tech;
    @Autowired //searches the class object by type
    //@Qualifier is used to search the class object by name
    private Laptop laptop;

    public Alian() {
        System.out.println("constrouctor output....");
    }

    public int getAid() {
        return aid;
    }

    public String getTech() {
        return tech;
    }

    public String getName() {
        return name;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTech(String tech) {
        this.tech = tech;
    }

    public Laptop getLaptop() {
        return laptop;
    }

    public void setLaptop(Laptop laptop) {
        this.laptop = laptop;
    }

    public void show(){
    System.out.println("Showing the alean class");
    laptop.compile();
}
}


