package com.example.springpractice1;

import antlr.actions.cpp.ActionLexer;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
//@EnableAutoConfiguration(exclude = {Laptop.class})
public class SpringPractice1Application {

	public static void main(String[] args) {

	ConfigurableApplicationContext context =  SpringApplication.run(SpringPractice1Application.class, args);
//     Alian al = context.getBean(Alian.class);
//	 al.show();
//	 Alian a1 = context.getBean(Alian.class);
//	 a1.show();
		Alian a = context.getBean(Alian.class);
		a.show();




	}

}
