package com.example.microservices.CitizenServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitizenServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
