public class demo1 {

    //input: welcome to salesboxai
    //output: emoclew ot iaoxbselas

    public static  void reverse (String st){

        StringBuffer stb = new StringBuffer();


        char [] ch = st.toCharArray();

        for(char i : ch){
                stb.append(i);
                stb.reverse();

        }
        System.out.println(stb.toString());

    }

    public static void main(String[] args) {
        String st  = "salesboxai";
       char []ch = st.toCharArray();



    }
}
