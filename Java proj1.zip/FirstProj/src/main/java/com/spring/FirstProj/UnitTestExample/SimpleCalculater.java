package com.spring.FirstProj.UnitTestExample;

public class SimpleCalculater {
    public  int add( int numberA, int numberB){
        return numberA+numberB;
    }
}
