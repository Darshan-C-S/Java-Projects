package com.spring.FirstProj.UnitTestExample;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SimpleCalculaterTest {
@Test
void TwoPlusTwoIsEqualToFour(){
    SimpleCalculater calculater = new SimpleCalculater();
    assertEquals(4,calculater.add(2,2));
//    assertTrue(calculater.add(3,3) == 6);
//    assertNotEquals(10,calculater.add(3,5)  );
//    assertFalse(calculater.add(5,5)==11);
}
    @Test
void ThreePlusThreeIsEqualTosix(){
    SimpleCalculater cal = new SimpleCalculater();
    assertEquals(6,cal.add(3,3));
}
}