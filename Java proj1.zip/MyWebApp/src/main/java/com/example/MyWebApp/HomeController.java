package com.example.MyWebApp;

import java.net.http.HttpRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController//annotation used to handle the request
public class HomeController {
    @RequestMapping(value = "/home" )
   
    public String home(HttpServletRequest req){ //initialise req parameter in the function
    	HttpSession session  = req.getSession(); // initialise the session
 
    	String name  = req.getParameter("name");
        System.out.println("this is home page");
        System.out.print("your name is:"+name);
        session.setAttribute("name", name);
        return "home";
    }
    
//    @Value("${server.port}")
//    private String serverPort;
//    
//    
//    @GetMapping("/codeDecode")
//  
//    public  void codeDecode() {
//    	System.out.println("My server port is "+serverPort);
//    }
}
