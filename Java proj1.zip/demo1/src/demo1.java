import java.util.*;


public class demo1 {

    public static int power(int n){
        for (int i = 0; i<n ; i++){
            for (int j = 0 ; j<n;j++){
                int a = (int) Math.pow(2,i);
                int b = (int) Math.pow(3,j);
                if(n == (a + b)){
                    return (i+j);
                }
            }
        }
        return 0;
    }

    public static void main(String[] args) {


    }
       Scanner sc = new Scanner(System.in);
       int r = sc.nextInt();
        int s = power(r);
             sout;



}
