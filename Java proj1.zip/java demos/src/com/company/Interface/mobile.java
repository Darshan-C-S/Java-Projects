package com.company.Interface;

interface Phone {
    void call();
    default void dial(){
        System.out.println("Dial 101");
    }
    static void num(){
        System.out.println("nowwfs");
    }
}
public class mobile implements Phone {
    public void call() {
        System.out.println("Enter the name");
    }



}
