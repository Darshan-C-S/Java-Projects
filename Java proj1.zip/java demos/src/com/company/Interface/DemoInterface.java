package com.company.Interface;

import java.util.Arrays;
import java.util.List;

interface a{
    void nu(int i);


}
interface b {
    void pr(String l);
}
interface num {
    String dig(String st);
    void show();
    static void number(){
        System.out.println("99102321");
    }
}
public class DemoInterface {
    public static void main(String[] args) {
        mobile m = new mobile();
        num n;
        a A;
        b B;
        String name = "Darshan";
        List<Integer> val = Arrays.asList(1,2,3,4);
        m.call();
        m.dial();
        num.number();//static implimentetion
        val.stream().map(x->x*x).forEach((i) -> System.out.println(i));
        A = (i) -> System.out.println("This is lambda interface "+i);// lamda implimentetion
        B = o ->System.out.println("This is lambda interface for String" + o );

        A.nu(3);
        B.pr("Hello World");



    }

    public static void digprint(String s ,  num n){
         String result = n.dig(s);
        System.out.println(result);
    }
}
