package com.company;

import java.util.Arrays;
import java.util.*;
import java.util.function.Consumer;

// class cons implements Consumer<Integer>{
//    public void accept(Integer i){
//        System.out.println(i);
//    }
//}
public class Consume {
    public static void main(String[] args) {
        List <Integer> no = Arrays.asList(1,2,3,4,5,6,8,7,10,9,12,11);
        Collections.sort(no);
//        Consumer c = new cons();
        Consumer<Integer> c = i -> System.out.println(i);
        no.forEach(c);
        System.out.println();
        ;
//        no.forEach(i -> System.out.println(i));
    }
}
