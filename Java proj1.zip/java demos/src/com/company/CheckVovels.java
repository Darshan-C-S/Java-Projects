package com.company;

import java.util.Locale;
import  java.util.*;

public class CheckVovels {
    public static boolean vovals(String a){
      return a.toLowerCase().matches(".*[a,e,i,o,u].*");
    }
    public static boolean conconents (String b){return b.toLowerCase().matches(".*[bcdfghjklmnpqrstvwxys].*");}
    public static void main(String[] args) {

        System.out.println(vovals("Darshan C S"));
        System.out.println(conconents("aeiou"));
    }
}
