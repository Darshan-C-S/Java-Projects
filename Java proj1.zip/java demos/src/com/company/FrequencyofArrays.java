package com.company;

import java.util.Arrays;

public class FrequencyofArrays {
    public static void freqCount(int[]arr , int n){

//       boolean[] visited = new boolean[n]; // create boolen array to check if element is checked or not by making it true or false
//        Arrays.fill(visited , false);// n is arr.length
//
//        for(int i = 0 ; i<n;i++){
//
//            if(visited[i] == true)// to skip if the array element is already counted
//                continue;
//
//            int count = 1;
//            for(int j = i+1; j<n;j++){
//                if(arr[i]==arr[j]){
//                    visited[j] = true;  //make the elements true as it gets counted through j index
//                    count++;
//                }
//            }
//            System.out.println(arr[i]+ " "+ count);
//        }
        boolean [] visited = new boolean[n];
        Arrays.fill(visited ,false);

        for(int i = 0 ; i<n ; i++){
            if(visited[i] == true){
                continue;
            }
            int count = 1;
            for (int j = i+1; j<n ;j++ ){
                if(arr[i] == arr[j]){
                    visited[j] =true;
                    count++;
                }
            }
            System.out.println(arr[i]+" "+count);
        }

    }
    public static void main(String[] args) {
        int [] a = {1,2,3,4,6,3};
        int l = a.length;
        freqCount(a,l);

    }
}
