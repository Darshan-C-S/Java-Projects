package com.company;

import java.util.HashMap;
import java.util.Scanner;

public class NoOfCharectorsInaString { // to check the frequency of charectors

    public static void count1 (String str){
        HashMap<Character , Integer> hash = new HashMap<>();
        for (int i= str.length()-1 ; i>=0 ; i--){
            if(hash.containsKey(str.charAt(i))){ // if there are more than one node
                int count  = hash.get(str.charAt(i));// gives a boolen value of the key if more than one present
                hash.put(str.charAt(i) , ++count);
            }
            else{
                hash.put(str.charAt(i) , 1);
            }

        }
        System.out.println(hash);
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the input ");
        String str = sc.next();
        count1(str);


//        HashMap<Character,Integer> hash = new HashMap<>();
//
//        for(int i  =  str.length()-1 ; i>=0;i--){
//            if(hash.containsKey(str.charAt(i))){
//                int count = hash.get(str.charAt(i));
//                hash.put(str.charAt(i) , ++count);
//            }
//            else {
//                hash.put(str.charAt(i),1);
//            }
//        }



//        for(int i = str.length()-1;i>=0;i--){
//            if(hash.containsKey(str.charAt(i))){ // to check weather it has multiple keys
//                int count = hash.get(str.charAt(i));// to get the initial count
//                hash.put(str.charAt(i),++count);
//
//            }
//            else{
//                hash.put(str.charAt(i),1);
//            }
//
//
//        }

//        System.out.println(hash);


    }












}

