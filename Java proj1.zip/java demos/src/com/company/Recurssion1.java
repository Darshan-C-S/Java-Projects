package com.company;

import java.util.Scanner;

public class Recurssion1 {
    public static int recadd(int n){
        if(n>0){
          return n + recadd(n-1);
        }
        else {
            return 0;
        }
    }
    public static int recadd2(int start , int end){
        if(end>start){
            return end + recadd2(start,end-1);
        }
        else {
            return end;
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the no :");
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("The sum of the no is :"+recadd(a));
        System.out.println("The sum between the two no is :"+ recadd2(a,b));
    }
}
