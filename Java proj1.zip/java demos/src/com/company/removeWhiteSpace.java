package com.company;

public class removeWhiteSpace {
    public static String removeWhite(String str) {
        StringBuilder st = new StringBuilder();
        char[] ch = str.toCharArray();

        for (char i : ch) {
            if (!Character.isSpaceChar(i)) {
                st.append(i);
            }
        }
        return st.toString();
    }
    public static void main(String[] args) {

        String srt = "Darshan C S";
        System.out.println(removeWhite(srt));

    }
}
