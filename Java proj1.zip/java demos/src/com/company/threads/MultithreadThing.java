package com.company.threads;

import java.security.PublicKey;

public class MultithreadThing extends Thread{
    public int ThreadNo;
    public MultithreadThing(int ThreadNo){
        this.ThreadNo = ThreadNo;
    }

    @Override
    public void run(){
        for(int i = 1;i<=5;i++){
            System.out.println(i +" from thread "+ThreadNo);
//            if (ThreadNo == 3){
//                throw new RuntimeException("Thread 3 is forbidden");
//            }
            try {
                Thread.sleep(1000);
            }catch (InterruptedException e){

            }
        }
        
    }
}
