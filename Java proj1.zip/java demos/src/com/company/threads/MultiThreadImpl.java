package com.company.threads;

public class MultiThreadImpl implements Runnable{/* its best practice to use interface runnable as the java doesnot
                                                     support multiple inheretence if its extends Threads */

    @Override
    public void run() {
        System.out.println("Run the implimented");
    }

    public static void main(String[] args) {
        MultiThreadImpl mi =new MultiThreadImpl();
        Thread th = new Thread(mi);
        th.start();
    }
}
