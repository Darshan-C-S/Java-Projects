package com.company.threads;

public class Multithreading {// we have to use start for the brand new threads rather than run as its used to run current thread
    public static void main(String[] args) {
//        MultithreadThing th  = new MultithreadThing();
//        MultithreadThing th1 = new MultithreadThing();
//        th.run();
//        th1.start();
        for (int i = 0 ; i<5 ; i++){
            MultithreadThing th2 = new MultithreadThing(i);
            th2.start();
        }
    }
}
