package com.company.threads;

public class threadClass extends Thread{//path at which the program is runned is called as thread , every class has one thread

    public void run(){//used to get the priyority
        System.out.println("The thread 1 is running "+ threadClass.currentThread().getPriority());
    }
    public static void main(String[] args) {
    threadClass th1 = new threadClass();
    threadClass th2 = new threadClass();
    threadClass th3 = new threadClass();
    th1.setPriority(threadClass.MIN_PRIORITY);  //these are the proyaority of exicution
    th2.setPriority(threadClass.NORM_PRIORITY);
    th2.setPriority(threadClass.MAX_PRIORITY);
    th1.start();
    th2.start();
    th3.start();
    }
}
