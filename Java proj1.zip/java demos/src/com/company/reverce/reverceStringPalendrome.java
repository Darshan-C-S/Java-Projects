package com.company.reverce;

public class reverceStringPalendrome {

    public static String rev(String st){

        if(st == null){
            throw new NullPointerException("Its a null value ");
        }

        StringBuilder str = new StringBuilder();
        char[] ch = st.toCharArray();
        for(int i = ch.length-1; i>=0 ; i--){
            str.append(ch[i]);
        }
        return str.toString();

    }
    public static void palen(String st){

        String rev = rev(st);
        if(rev.equals(st)){ //use .equals  method insted of ==
            System.out.println("they are palindrome ");
        }
        else {
            System.out.println("they are not palindrome");
        }
    }

    public static void main(String[] args) {

        String name  = "ABBA";
        palen(name);
        System.out.println(rev(name));
    }
}
