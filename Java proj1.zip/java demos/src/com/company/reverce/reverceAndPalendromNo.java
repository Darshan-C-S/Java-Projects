package com.company.reverce;

public class reverceAndPalendromNo {
    public static int rev (int n){
        int rev = 0;

        if(n < 10 ){
            throw new RuntimeException("Single digits cannot be reversed ");
        }
        while (n>0){
           int rem = n%10;
            rev = (rev*10)+rem;
            n=n/10;
        }
        return rev;

    }

    public static void palend(int n){
        if(rev(n)==n){
            System.out.println("They are palindrome");
        }
        else {
            System.out.println("they are not palindrome");
        }
    }
    public static void main(String[] args) {

        int n = 2121;
        palend(n);
        System.out.println(rev(n));
    }
}
