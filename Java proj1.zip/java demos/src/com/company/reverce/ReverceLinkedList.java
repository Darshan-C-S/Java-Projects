package com.company.reverce;

import java.util.LinkedList;

public class ReverceLinkedList {
    public static void main(String[] args) {
        LinkedList<Integer> an = new LinkedList<>();
        an.add(1);
        an.add(2);
        an.add(3);
        an.add(4);
        an.add(5);

        LinkedList<Integer> li = new LinkedList<>();
        System.out.println(an);

        an.descendingIterator().forEachRemaining(li::add); // inbulit method to add the elements
        System.out.println(li);


    }
}
