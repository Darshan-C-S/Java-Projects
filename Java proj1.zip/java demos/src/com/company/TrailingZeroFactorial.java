package com.company;

public class TrailingZeroFactorial {
    public static int TrailingZFact(int z){
        int res = 0;
        for (int i = 5 ; i<=z ; i*=5){
            res = res + z/i;
        }
        return res;
    }
    public static void main(String[] args) {
        System.out.println(TrailingZFact(10));
    }
}
