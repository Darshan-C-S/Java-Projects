package com.company;

public class SwapByBitwise {
    public static void swapNo (int a , int b){
        a = a^b;
        b = a^b;
        a = a^b;
        System.out.println("The swaped no's are : a = " +a +" b= "+b);
    }
    public static void main(String[] args) {
        int a  = 10;
        int b = 11;
        swapNo(a,b);
    }
}
