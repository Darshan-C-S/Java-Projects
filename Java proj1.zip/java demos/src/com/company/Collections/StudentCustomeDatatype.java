package com.company.Collections;

import java.security.PublicKey;
import java.util.Objects;

public class StudentCustomeDatatype {
    public int id;
    public String name;


    public StudentCustomeDatatype(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {    //to give the output for the value
        return "StudentCustomeDatatype{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) { // its used to check weather the values are eqal
        if (this == o) return true;
        if (!(o instanceof StudentCustomeDatatype)) return false;
        StudentCustomeDatatype that = (StudentCustomeDatatype) o;
        return id == that.id && name.equals(that.name);
    }

    @Override
    public int hashCode() {   //here we use it to convert id to hash codes which doesn't allow duplicate value
        return Objects.hash(id);
    }
}
