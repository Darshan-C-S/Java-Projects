package com.company.Collections;
import java.lang.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Arraylists {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        List<Integer> in = new ArrayList<>();

        list.add("Darshan");
        in.add(1);
        in.add(2);
        in.add(3);
        in.add(4);
        in.add(5);
        System.out.println(in);
        System.out.println(in.get(1));


        Iterator<Integer> it = in.iterator();
        while (it.hasNext()){
            System.out.println("iterator :" + it.next());//.next() is used to get the next value
        }
//        // remove ops
//        in.remove(2);
//        in.remove(Integer.valueOf(5));
//        System.out.println(in);
//        //in.clear();used to clear the entier list

//        //set the element
//        in.set(2,1000);
//        System.out.println(in);
//        System.out.println(in.contains(1));
        for (Integer i :in){
            System.out.println(i);
        }





    }
}
