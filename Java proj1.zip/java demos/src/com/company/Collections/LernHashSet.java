package com.company.Collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class LernHashSet {
    public static void main(String[] args) {
        Set<Integer> st = new HashSet<>();// the elements are hashed  which makes them unordered as there is no index O(1)
        LinkedHashSet<Integer> lh = new LinkedHashSet<>();//uses the property's of linked list and elements are in order
        Set<Integer>th = new TreeSet<>();// elements are arranged in a sorted manner due to binary tree property's O(log n)
        st.add(10);
        st.add(20);
        st.add(30);
        st.add(40);

        lh.add(10);
        lh.add(20);
        lh.add(30);
        lh.add(40);
        System.out.println(st);
        for (Integer i :st){
            System.out.println(i);
        }
        System.out.println(st.contains(10));
        for (Integer j : lh){
            System.out.println(j);
        }
    }
}
