package com.company.Collections;

import java.util.ArrayDeque;

public class LernArrayDequeue {
    public static void main(String[] args) {

        ArrayDeque<Integer> dq = new ArrayDeque<>(); //similar to queue, but we can do same operations both the ends
        dq.offer(10);// we use method offer insted of add as its handles the exception by giving false if the operation fails
        dq.offerFirst(20);
        dq.offerLast(30);
        dq.offer(40);
        System.out.println(dq);

        for (Integer in:dq) {
            System.out.println(in);
        }

        System.out.println("these are peek operetions "+dq.peek());
        System.out.println(dq.peekFirst());
        System.out.println(dq.peekLast());

        System.out.println(dq.poll());
        System.out.println(dq.pollFirst());
        System.out.println(dq.pollLast());

        for (Integer in:dq) {
            System.out.println(in);
        }


    }
}
