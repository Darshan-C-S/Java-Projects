package com.company.Collections;

import org.w3c.dom.ls.LSOutput;

import java.util.PriorityQueue;
import java.util.*;

public class PrayorityQueue {
   public static void main(String[] args) {
      Queue<Integer> pq = new PriorityQueue<>(Comparator.reverseOrder());// reverce order makes the queue in decending order
      pq.offer(10);
      pq.offer(20);
      pq.offer(40);
      pq.offer(30);

      System.out.println(pq);
      System.out.println(pq.peek());
      pq.poll();// after polling the queue sorts itself in ascending order
      System.out.println(pq);

   }






}
