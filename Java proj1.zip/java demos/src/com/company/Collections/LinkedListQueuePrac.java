package com.company.Collections;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class LinkedListQueuePrac {
    public static void main(String[] args) { // queue fallowes FIFO
        Queue<Integer> qu = new LinkedList<>(); //linked list is used to impliment queue
        List<Integer> list = new LinkedList<>(); // all the function is same as array list as its from list interface

        qu.offer(12);// we use it to add the elements , we can use add() and returns true but its not safe as
        qu.offer(40);// it throws an exception when the element is not added but offer returns true or false
        qu.offer(90);
        qu.offer(120);

        System.out.println(qu);
        System.out.println(qu.poll());// removes the last element and returns the value we can use remove() but throwes
                                        //an exception if queue is empty

        System.out.println(qu);
        System.out.println(qu.peek());// to see the value next in line to be removed returns null if queue is empty
                                      //we can use element() but throwes exception if queue is empty


    }
}
