package com.company.Collections;

import java.util.*;

public class StackPrac { // Stack fallowes LIFO
    public static void main(String[] args) {
        Stack<String> st = new Stack<>();
        st.push("Lion");
        st.push("Tiger");
        st.push("cat");
        st.push("dog");
        st.push("Dragon");

        System.out.println(st);
        System.out.println(st.peek());// as its lifo it peeks into the first element
        st.pop(); //removes first element
        System.out.println(st.peek());



    }

}
