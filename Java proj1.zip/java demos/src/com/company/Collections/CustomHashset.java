package com.company.Collections;

import java.util.HashSet;
import java.util.Set;

public class CustomHashset {
    public static void main(String[] args) {
        Set<StudentCustomeDatatype>st = new HashSet<StudentCustomeDatatype>();

        st.add(new StudentCustomeDatatype(1,"Darshan C S"));// we should use the the new class refrence to add the data type
        st.add(new StudentCustomeDatatype(2,"Mira"));
        st.add(new StudentCustomeDatatype(3,"Sham"));
        st.add(new StudentCustomeDatatype(4,"Hello World"));

        st.add(new StudentCustomeDatatype(1,"Darshan C S"));// the hash set cannot identifi the different
        // elements used so we have to genarate equals and hashCode in the pojo StudentCustomeDatatype

//        StudentCustomeDatatype s1 = new StudentCustomeDatatype(1,"Darshan C S");
//        StudentCustomeDatatype s2 = new StudentCustomeDatatype(1,"Mira");
//        System.out.println(s1.equals(s2));

        System.out.println(st);
        }



}
