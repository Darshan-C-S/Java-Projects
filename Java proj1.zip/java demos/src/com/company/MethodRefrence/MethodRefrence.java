package com.company.Methodrefrence;

public class MethodRefrence {
    public static void main(String[] args) {

    }
}
