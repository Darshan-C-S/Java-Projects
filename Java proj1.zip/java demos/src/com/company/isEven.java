package com.company;

public class isEven {

    public static void even(int n){
        if(n%2 == 0){
            System.out.println("the no is even");
        }
        else{
            System.out.println("The no is odd");
        }
    }
    public static void bitviseEven (int n){
        if((n&1) == 0){
            System.out.println("The no is even");
        }
       else {
            System.out.println("The no is odd");
        }
    }
    public static void main(String[] args) {
        int n  = 11;
        even(n);
        bitviseEven(n);

    }
}
