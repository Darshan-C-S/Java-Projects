package com.company.Exeption;
import java.io.*;
import java.util.*;

public class CheckedException {
    public static void main(String[] args) {
        readFile(new File("Myfile.txt"));


    }
    private static void readFile(File file) {
       try {
           FileReader reader  = new FileReader(file);
       }
       catch (FileNotFoundException fnfe){
           System.out.println("The file is not found");
       }
    }
}
