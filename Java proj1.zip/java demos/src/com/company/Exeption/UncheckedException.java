package com.company.Exeption;

public class UncheckedException {
    public static void main(String[] args) {
        String st = null;
        lenOfstring(st);
    }
    public static void lenOfstring(String s){
        System.out.println(s.length());
    }//here the string is null and its not handled so its giving an unchecked exception
}
