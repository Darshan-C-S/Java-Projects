package com.company.Exeption;

public class LessThanZeroExeption extends Exception {
    public LessThanZeroExeption(){}
public LessThanZeroExeption(String message , Throwable cause){ /*message is used to pass custom exception
                                                                 and throweable can be used to pass inbuilt exception
                                                                    */
    super(message,cause);


}
}
