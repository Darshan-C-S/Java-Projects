package com.company.Exeption;

public class CustomExeption {

    public static void validateAge(int i) throws LessThanZeroExeption {
        if (i<0){
            throw new LessThanZeroExeption("The age enterd is wrong it is negetive : ",new RuntimeException());

        }
    }

    public static void main(String[] args) throws LessThanZeroExeption{

        validateAge(-11);
    }
}
