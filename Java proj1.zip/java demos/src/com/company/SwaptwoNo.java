package com.company;

public class SwaptwoNo {
    public static void swap(int a, int b){
        b = a+b;
        a= b-a;
        b = b-a;
        System.out.println("the swaped no is "+ a + " "+b);;
    }

    public static void main(String[] args) {
        swap(10,20);
    }
}
