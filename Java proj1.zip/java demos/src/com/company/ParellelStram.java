package com.company;
import java.util.stream.*;
import java.util.*;

public class ParellelStram {


    public static void main(String[] args) {
        System.out.println("Normal Stream api");
        IntStream in  = IntStream.rangeClosed(1,5);
        in.forEach(System.out::println);

        System.out.println("Normal stream 2");
        IntStream ins  = IntStream.rangeClosed(1,10);
        ins.forEach(System.out::println);

        System.out.println("Parallel stream ");
        IntStream in2 = IntStream.rangeClosed(1,5);
        in2.parallel().forEach(System.out::println);



        List<Integer> r = Arrays.asList(1,2,3,4,5,6);
        // normal stream
        System.out.println("Normal Stream api");
        List<Integer>n = r.stream().map(x -> x*2).collect(Collectors.toList());
        System.out.println(n);
        // parllel stream
        System.out.println("Parallel stream ");
        List<Integer> p = r.parallelStream().map(x->x*2).collect(Collectors.toList());
        System.out.println(p);




    }
}
