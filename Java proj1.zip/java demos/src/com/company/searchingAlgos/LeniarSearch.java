package com.company.searchingAlgos;

import java.util.Scanner;

public class LeniarSearch {

    public static int LinSirch(int[] a , int x){
        int n = a.length;
        for (int i = 0 ; i<n ; i++){
            if(a[i] == x){
                return i;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int [] arr = {1,2,3,4,5,6,7,8};
        System.out.println("Enter the elment to be searched : ");
        int s = sc.nextInt();

        int b  = LinSirch(arr , s);
        if(b==-1){
            System.out.println("The element doesnot exisit:");
        }
        else {
            System.out.println("The element is in the position of : " +b);
        }

    }
}
