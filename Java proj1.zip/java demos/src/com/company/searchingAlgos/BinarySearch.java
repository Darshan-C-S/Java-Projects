package com.company.searchingAlgos;

import java.util.Scanner;

public class BinarySearch {
    public static int binsearch(int[] arr , int x){
        int low  = 0 , high  = arr.length-1;

        while (low<=high){
            int mid =(low+high)/2;
            if(arr[mid] == x){
                return mid ;
            }
            if(arr[mid]<x){
                low = mid+1;
            }
            else if (arr[mid]>x){
                high = mid-1;
            }
        }
        return -1;
    }
    public static int binsearchRec(int[] arr , int x, int low , int high){
       if(low<high) {
           int mid = (low + high) / 2;
           if (arr[mid] == x) {
               return mid;
           }else if(arr[mid]<x){
              return binsearchRec(arr , x , mid+1 , high);
           }
           else if  (arr[mid] > x) {
               return binsearchRec(arr , x , low , mid-1);
           }
       }
          return -1;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int [] arr = {1,2,3,4,5,6,7,8};
        System.out.println("Enter the elment to be searched : ");
        int s = sc.nextInt();

        int b  = binsearch(arr , s);
        if(b==-1){
            System.out.println("The element doesnot exisit:");
        }
        else {
            System.out.println("The element is in the position of : " +b);
        }

    }
}
