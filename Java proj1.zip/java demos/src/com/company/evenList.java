package com.company;

import java.util.ArrayList;
import java.util.Arrays;

public class evenList {



        public static void main (String[]args){
            ArrayList<Integer> ar = new ArrayList<>();
            ArrayList<Integer>are = new ArrayList<>();
            ar.add(1);
            ar.add(2);
            ar.add(3);
            ar.add(4);
            ar.add(5);
            ar.add(6);
        for (Integer i:ar) {
//            System.out.println(i);
            if(i%2==0){
                are.add(i);
        }
        }
            System.out.println(are);
    }
}
