package com.company.sortingAlgos;

import java.util.HashMap;
import java.util.Scanner;

public class BubbleSort {
    public static void PrintArr(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i] + " ");
        }
    }

    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 7, 9, 10, 5, 6};

        for (int i = 0; i < a.length - 1; i++) { //traverse through the array O(n) take size n-1 in consideration
            for (int j = 0; j < a.length - i - 1; j++) {// looping Comparison through dic-rising index order


                //sort
                if (a[j] > a[j + 1]) {   // for descending order make condition reverse ie(a[j]<a[j+1])
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                }
            }

        }
        PrintArr(a);
    }

}