package com.company.sortingAlgos;

public class SelectionSort {
    public static void PrintArr(int []Arr){
        for (int  i = 0 ; i<Arr.length-1;i++){
            System.out.println(Arr[i]);
        }
    }

    public static void main(String[] args) {//O(n^2)
        int [] a = {1,2,3,4,8,5,7,6};

        for(int i = 0 ; i<a.length-1;i++){
            int Small = i;// use the smallest index
            for(int j = i+1 ; j<a.length;j++){ // looping Comparison through increasing index order

                if(a[Small]>a[j]){ //compare the smallest index element and assign it if its bigger than next element
                    Small = j; //for descending order make condition reverse ie (a[Small]<a[j])
                }
            }
            int temp = a[Small];
            a[Small]= a[i];
            a[i]= temp;
        }
        PrintArr(a);
    }
}
