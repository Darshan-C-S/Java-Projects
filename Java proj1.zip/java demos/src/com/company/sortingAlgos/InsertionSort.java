package com.company.sortingAlgos;

public class InsertionSort {
    public static void PrintArr(int []arr){
        for (int i  = 0 ; i<arr.length ;i++){
            System.out.println(arr [i] + " ");
        }
    }
    public static void main(String[] args) {
        int [] a = {1,3,5,2,6,9,7,4,10};

//insert sort
        for(int i = 1; i<a.length; i++){// position is from index 1 by assuming 0 th position or first pos is sorted
            int current = a[i];
            System.out.println(current);

            int j = i-1; //set j as first position of array index
            while (j>=0 && current <a[j]){ //j>=0 is used to avoid ArrayIndexOutOfBounds Exception when index is -ve
                a[j+1] = a[j];// crate a blank space to add the element b/w as they compare b/ current and next element
                j--;
            }
            //placement
            a[j+1] = current;
        }
        System.out.println("The output is :");
        PrintArr(a);
    }
}
