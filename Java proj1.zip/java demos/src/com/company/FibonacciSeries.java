package com.company;

public class FibonacciSeries {

    public static  int  fibo(int n){
        if(n<=1)
            return n ;
        return fibo(n-1)+fibo(n-2);

    }
    public static void main(String[] args) {

        int a = 10;
        System.out.println(fibo(a));
    }
}
