package com.company;

import java.util.Scanner;

public class SumOfNumbers {
    public static int sum(int a){
        int s = 0;
        while(a !=0){
            s = s+a%10;
            a = a/10;
        }
        return s;
    }
    public static int sum2(int n){
       if(n>0){
           return n + sum2(n-1);
       }
      else{
           return 0;
       }
    }
    public static void main(String[] args) {

        Scanner sc  = new Scanner(System.in);
        System.out.println("Eneter the input");
        int l  =  sc.nextInt();
        System.out.println("The output sum is :" + sum(l));
        System.out.println("The recursion out put of this is : "+sum2(l));;

    }
}
