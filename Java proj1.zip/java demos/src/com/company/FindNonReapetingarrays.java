package com.company;


public class FindNonReapetingarrays {

    public static int findSingleNonReapeate(int [] arr){
        int rep = 0;
        for (int i = 0; i< arr.length  ; i++){


                    rep = rep ^ arr[i];


        }
        return rep;
    }
    public static void main(String[] args) {

        int [ ] arr = {1,3,4,5,5};
        System.out.println(findSingleNonReapeate(arr));;
    }
}
