package com.company;

import org.w3c.dom.ls.LSOutput;

import java.util.*;
import java.util.stream.Collectors;
//map filter sorted is intermediate operetions
//Terminal operetions are collect forEach and reduce


public class StreamApi {
   public static void main(String[] args) {
      Integer []a = new Integer[]{1,2,3,4,5,7,8,6,10,9};
      List<Integer> li = Arrays.asList(a);
//      List<Integer> rl = Arrays.asList(1,2,3,4,5,6,7,8);
//      rl.stream().map(f->f*f).forEach(g -> System.out.println(g));

      List<String> names = Arrays.asList("Reflection","Collection","Stream");

      //Stram map function
      List<Integer> sq  = li.stream().map(x -> x*x ).collect(Collectors.toList());
      List<Integer> db = li.stream().map(i -> i*2).collect(Collectors.toList());

      //stream filter
      List<Integer> fl = li.stream().filter( n  -> n>2).collect(Collectors.toList());
      List<String>st  = names.stream().filter((s -> s.startsWith("S"))).collect(Collectors.toList());
      //stream sorted
      List<Integer> sr = li.stream().sorted().collect(Collectors.toList());
      //Stream collect
      List<String> cll = names.stream().collect(Collectors.toList());
//      cll.stream().forEach(x-> System.out.println(x));

      //Stream forEach
      li.stream().map(b->b*3).forEach(z -> System.out.println(z));

      //reduce
      int ev = li.stream().filter(x ->x%2==0).reduce(0,(k,j) -> k+j);//index value and functions
      System.out.println("Result for reduce "+ev);
   }





}
